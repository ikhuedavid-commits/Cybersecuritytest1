/*
 * © 2026 SeXyxeon (VOIDSEC)
 *
 * ⚠️ COPYRIGHT NOTICE
 * This source code is protected under copyright law.
 * Any form of re-uploading, recoding, modification,
 * selling, or redistribution WITHOUT explicit permission
 * from the original author is strictly prohibited.
 *
 * ❌ NO CREDIT = NO PERMISSION
 * ❌ DO NOT CLAIM THIS CODE AS YOUR OWN
 *
 * ✔️ Usage or modification is allowed ONLY
 * with prior permission and proper credit.
 *
 * OFFICIAL LINKS (ONLY):
 * YouTube   : https://youtube.com/@voidsec7718
 * Instagram : sabir._7718
 * Telegram  : https://t.me/SABIR7718
 * GitHub    : https://github.com/SABIR7718
 * WhatsApp  : +91 73650 85213
 *
 * Violations may result in DMCA takedown
 * or termination of the Telegram bot.
 */
module.exports = {
    mainToken: '9231789580:AAEVMH4pPV-ADIZxGXjLtyJQD0hekeW7IYE', // Bot Token Here 
    
    S7: '@SYxS7', // Owner, Name
    
    adminId: '8609447789', // Owner Chat ID ( control /address, /delresell )
    
    channel: 'https://t.me/obitomdbot122', // TG channel link
    
    group: 'https://t.me/obitomd_bug', // TG group link
    
    youtube: 'https://youtube.com/Tech_with_Shamrez', // YouTube Link
    
    waChannel: 'https://whatsapp.com/channel/0029Vb8Zfck6rsQvotJQ4E2Y', // WhatsApp Channel Link
    
    instagram: 'https://www.instagram.com/?=MTdlcHlwaW9wNnBqaw==', // Instagram Link 
    
    channelId: '-1004444334715', // channel ID bot must be admin in the channel
    
    groupId: '-1003926547908', // group ID bot must be admin in the group
    
    bot: 'SYxS7 V2', // Bot name 
    
    logo: './SY/Loves.jpg' // Bot logo path or URL
};


